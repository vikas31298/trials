import os
import pickle
import torch
from transformers import BertTokenizer, BertForSequenceClassification

class EmailClassifier:
    def __init__(self):
        self.model_dir = os.path.dirname(os.path.abspath(__file__))
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.load_model()

    def load_model(self):
        """Load the trained model and components"""
        self.tokenizer = BertTokenizer.from_pretrained(self.model_dir)
        self.model = BertForSequenceClassification.from_pretrained(self.model_dir)
        self.model.to(self.device)
        self.model.eval()
        
        with open(os.path.join(self.model_dir, 'label_encoder.pkl'), 'rb') as f:
            self.label_encoder = pickle.load(f)

    def classify(self, text):
        """Classify email text"""
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=512,
            padding='max_length'
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.model(**inputs)
        
        predicted_idx = torch.argmax(outputs.logits).item()
        predicted_label = self.label_encoder.inverse_transform([predicted_idx])[0]
        confidence = torch.softmax(outputs.logits, dim=1)[0][predicted_idx].item()
        
        department, email_type = predicted_label.split('_')
        return {
            'department': department,
            'type': email_type,
            'confidence': confidence
        }