ALREADY TRAINED MODEL (FOLDER): email_classifier_model
DUMMY EMAILS: dummy_emails.csv
IF YOU WANT TO TRAIN MODEL: train_email_classifier.py
INTEGRATE WITH OUTLOOK USING PYTHON: outlook_email_classifier.py
INTEGRATE WITH OUTLOOK USING C# (outlook plugin):
1. EmailClassifierAddin.cs
2. email_classifier.py
