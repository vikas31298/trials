import win32com.client
import pickle
from transformers import BertTokenizer, BertForSequenceClassification
import torch
import os
import logging
from datetime import datetime
import pythoncom

# Configure logging
logging.basicConfig(
    filename='C:\\Desktop\\outlook_email_classifier.log', #change with your location
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class OutlookEmailClassifier:
    def __init__(self):
        # Initialize COM
        pythoncom.CoInitialize()
        
        # Load model and components (change with your location)
        self.model_dir = 'C:\\Desktop\\email_classifier_model'
        self.load_model()
        
        # Outlook setup
        self.outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        self.inbox = self.outlook.GetDefaultFolder(6)  # Inbox folder
        self.processed_ids = set()
        self.load_processed_ids()
        
        logging.info("Outlook Email Classifier initialized successfully")

    def load_model(self):
        """Load the trained model and associated files"""
        try:
            self.tokenizer = BertTokenizer.from_pretrained(self.model_dir)
            self.model = BertForSequenceClassification.from_pretrained(self.model_dir)
            
            with open(os.path.join(self.model_dir, 'label_encoder.pkl'), 'rb') as f:
                self.label_encoder = pickle.load(f)
                
            with open(os.path.join(self.model_dir, 'label_mapping.json'), 'r') as f:
                import json
                self.label_mapping = json.load(f)
                
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            self.model.to(self.device)
            self.model.eval()
            
            logging.info("Model loaded successfully")
        except Exception as e:
            logging.error(f"Error loading model: {str(e)}")
            raise

    def load_processed_ids(self):
        """Load already processed email IDs to avoid reprocessing"""
        try:
            if os.path.exists('processed_emails.pkl'):
                with open('processed_emails.pkl', 'rb') as f:
                    self.processed_ids = pickle.load(f)
        except Exception as e:
            logging.warning(f"Could not load processed emails: {str(e)}")

    def save_processed_ids(self):
        """Save processed email IDs"""
        try:
            with open('processed_emails.pkl', 'wb') as f:
                pickle.dump(self.processed_ids, f)
        except Exception as e:
            logging.warning(f"Could not save processed emails: {str(e)}")

    def classify_email(self, text):
        """Classify email text into department and type"""
        try:
            inputs = self.tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=512,
                padding='max_length'
            ).to(self.device)
            
            with torch.no_grad():
                outputs = self.model(**inputs)
            
            predicted_idx = torch.argmax(outputs.logits).item()
            predicted_label = self.label_encoder.inverse_transform([predicted_idx])[0]
            confidence = torch.softmax(outputs.logits, dim=1)[0][predicted_idx].item()
            
            department, email_type = predicted_label.split('_')
            return department, email_type, confidence
        except Exception as e:
            logging.error(f"Classification error: {str(e)}")
            return "Uncategorized", "Unknown", 0.0

    def get_or_create_folder(self, parent, folder_name):
        """Get existing folder or create new one"""
        try:
            # Check if folder exists
            for folder in parent.Folders:
                if folder.Name == folder_name:
                    return folder
            # Create if not exists
            return parent.Folders.Add(folder_name)
        except Exception as e:
            logging.error(f"Folder error ({folder_name}): {str(e)}")
            return None

    def move_to_folder(self, mail, department, email_type):
        """Move email to appropriate folder"""
        try:
            if not department or not email_type:
                return False
                
            # Get or create department folder
            inbox_parent = self.inbox.Parent
            dept_folder = self.get_or_create_folder(inbox_parent, department)
            if not dept_folder:
                return False
                
            # Get or create type subfolder
            type_folder = self.get_or_create_folder(dept_folder, email_type)
            if not type_folder:
                return False
                
            # Move the email
            mail.Move(type_folder)
            logging.info(f"Moved email to {department}/{email_type}")
            return True
        except Exception as e:
            logging.error(f"Move error: {str(e)}")
            return False

    def process_new_emails(self):
        """Process all unread emails in inbox"""
        try:
            unread_emails = self.inbox.Items.Restrict("[UnRead] = True")
            processed_count = 0
            
            for mail in unread_emails:
                try:
                    if mail.Class == 43 and mail.EntryID not in self.processed_ids:  # MailItem
                        email_text = f"Subject: {mail.Subject}\n\n{mail.Body}"
                        
                        department, email_type, confidence = self.classify_email(email_text)
                        
                        if confidence > 0.5:  # Only move if confident
                            success = self.move_to_folder(mail, department, email_type)
                            if success:
                                self.processed_ids.add(mail.EntryID)
                                processed_count += 1
                                mail.UnRead = False  # Mark as read
                        else:
                            logging.info(f"Low confidence ({confidence:.2f}) for email: {mail.Subject}")
                except Exception as e:
                    logging.error(f"Error processing email: {str(e)}")
                    continue
            
            self.save_processed_ids()
            logging.info(f"Processed {processed_count} new emails")
            return processed_count
        except Exception as e:
            logging.error(f"Processing error: {str(e)}")
            return 0

    def run(self):
        """Main execution loop"""
        logging.info("Starting email classification service")
        try:
            while True:
                try:
                    processed = self.process_new_emails()
                    logging.info(f"Processed {processed} emails in this batch")
                    
                    # Wait before next check (e.g., 5 minutes)
                    import time
                    time.sleep(300)
                    
                except KeyboardInterrupt:
                    logging.info("Service stopped by user")
                    break
                except Exception as e:
                    logging.error(f"Runtime error: {str(e)}")
                    time.sleep(60)  # Wait before retry
        finally:
            self.save_processed_ids()
            pythoncom.CoUninitialize()

if __name__ == "__main__":
    try:
        classifier = OutlookEmailClassifier()
        
        # Run either as continuous service or one-time processing
        run_as_service = False  # Change to True for continuous running
        
        if run_as_service:
            classifier.run()
        else:
            processed = classifier.process_new_emails()
            print(f"Processed {processed} new emails. Check outlook_email_classifier.log for details.")
            
    except Exception as e:
        logging.error(f"Initialization failed: {str(e)}")
        print(f"Error: {str(e)}")