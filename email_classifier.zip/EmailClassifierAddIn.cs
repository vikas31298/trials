using System;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Outlook;
using Python.Runtime;

namespace EmailClassifierAddIn
{
    public partial class ThisAddIn
    {
        private Inspector _currentInspector;
        private dynamic _pythonModel;

        private void ThisAddIn_Startup(object sender, EventArgs e)
        {
            // Initialize Python engine
            InitializePython();
            
            // Add ribbon button
            AddRibbonButton();
            
            // Set up event handlers
            Application.Inspectors.NewInspector += Inspectors_NewInspector;
        }

        private void InitializePython()
        {
            try
            {
                // Set path to your Python installation (change with your location)
                Runtime.PythonDLL = @"C:\Python313\python.dll";
                
                // Initialize Python runtime
                PythonEngine.Initialize();
                using (Py.GIL())
                {
                    // Add path to your model directory (change with your location)
                    dynamic sys = Py.Import("sys");
                    sys.path.append(@"C:\Desktop\email_classifier_model");
                    
                    // Import your Python classifier (change with your location)
                    dynamic classifier = Py.Import(@"C:\Desktop\email_classifier.py");
                    _pythonModel = classifier.EmailClassifier();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Python initialization failed: {ex.Message}");
            }
        }

        private void AddRibbonButton()
        {
            // Create a custom ribbon tab
            CommandBars cmdBars = Application.ActiveExplorer().CommandBars;
            CommandBar ribbonBar = cmdBars.Add("Email Classifier", Temporary: true);
            
            // Add classify button
            CommandBarButton classifyBtn = (CommandBarButton)ribbonBar.Controls.Add(
                MsoControlType.msoControlButton, Temporary: true);
            
            classifyBtn.Caption = "Classify Email";
            classifyBtn.Style = MsoButtonStyle.msoButtonIconAndCaption;
            classifyBtn.Click += ClassifyBtn_Click;
            
            ribbonBar.Visible = true;
        }

        private void Inspectors_NewInspector(Inspector inspector)
        {
            if (inspector.CurrentItem is MailItem mailItem)
            {
                _currentInspector = inspector;
            }
        }

        private void ClassifyBtn_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            if (_currentInspector?.CurrentItem is MailItem mailItem)
            {
                try
                {
                    string emailText = $"Subject: {mailItem.Subject}\n\n{mailItem.Body}";
                    
                    using (Py.GIL())
                    {
                        // Call Python model
                        dynamic result = _pythonModel.classify(emailText);
                        string department = result.department;
                        string emailType = result.type;
                        double confidence = result.confidence;
                        
                        // Move to appropriate folder
                        MoveToFolder(mailItem, department, emailType);
                        
                        // Show result
                        MessageBox.Show($"Classified as: {department}/{emailType}\nConfidence: {confidence:P}");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Classification failed: {ex.Message}");
                }
            }
        }

        private void MoveToFolder(MailItem mail, string department, string emailType)
        {
            try
            {
                MAPIFolder parentFolder = mail.Parent as MAPIFolder;
                MAPIFolder deptFolder = GetOrCreateFolder(parentFolder, department);
                MAPIFolder typeFolder = GetOrCreateFolder(deptFolder, emailType);
                
                mail.Move(typeFolder);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Couldn't move email: {ex.Message}");
            }
        }

        private MAPIFolder GetOrCreateFolder(MAPIFolder parent, string folderName)
        {
            try
            {
                foreach (MAPIFolder folder in parent.Folders)
                {
                    if (folder.Name == folderName)
                        return folder;
                }
                return parent.Folders.Add(folderName);
            }
            catch
            {
                return parent.Folders.Add(folderName);
            }
        }

        private void ThisAddIn_Shutdown(object sender, EventArgs e)
        {
            // Clean up Python
            if (PythonEngine.IsInitialized)
                PythonEngine.Shutdown();
        }

        #region VSTO generated code
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        #endregion
    }
}