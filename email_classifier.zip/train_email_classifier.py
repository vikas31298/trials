import pandas as pd
import numpy as np
import pickle
import json
import os
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, f1_score
from transformers import (
    BertTokenizer,
    BertForSequenceClassification,
    Trainer,
    TrainingArguments,
    EarlyStoppingCallback
)
import torch
from torch.utils.data import Dataset

# Set random seeds for reproducibility
np.random.seed(42)
torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(42)

class EmailDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=256):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = str(self.texts[idx])
        encoding = self.tokenizer(
            text,
            truncation=True,
            max_length=self.max_length,
            padding='max_length',
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(self.labels[idx], dtype=torch.long)
        }

def compute_metrics(pred):
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    return {
        'accuracy': accuracy_score(labels, preds),
        'f1_macro': f1_score(labels, preds, average='macro')
    }

def train_email_classifier():
    # Load data
    df = pd.read_csv('C:\\Desktop\\dummy_emails.csv') #change with your location
    
    # Create combined labels
    df['combined_label'] = df['department'] + "_" + df['email_type']
    
    # Encode labels - convert to native Python int
    label_encoder = LabelEncoder()
    df['label'] = label_encoder.fit_transform(df['combined_label']).astype(int)
    
    # Split data (stratified)
    train_df, test_df = train_test_split(
        df,
        test_size=0.2,
        stratify=df['label'],
        random_state=42
    )
    
    # Create output directory with timestamp (change with your location)
    output_dir = f"C:\\Desktop\\email_classifier_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(output_dir, exist_ok=True)
    
    # Save label artifacts first
    with open(os.path.join(output_dir, 'label_encoder.pkl'), 'wb') as f:
        pickle.dump(label_encoder, f)
    
    label_mapping = {
        str(cls): int(idx) 
        for cls, idx in zip(label_encoder.classes_, label_encoder.transform(label_encoder.classes_))
    }
    with open(os.path.join(output_dir, 'label_mapping.json'), 'w') as f:
        json.dump(label_mapping, f, indent=2)
    
    # Initialize tokenizer and model
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model = BertForSequenceClassification.from_pretrained(
        'bert-base-uncased',
        num_labels=len(label_encoder.classes_)
    )
    
    # Create datasets
    train_dataset = EmailDataset(train_df['text'].tolist(), train_df['label'].tolist(), tokenizer)
    test_dataset = EmailDataset(test_df['text'].tolist(), test_df['label'].tolist(), tokenizer)
    
    # Training arguments with checkpointing
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=5,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=16,
        learning_rate=2e-5,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model='f1_macro',
        logging_dir=os.path.join(output_dir, 'logs'),
        logging_steps=50,
        warmup_steps=100,
        save_total_limit=2,
        seed=42,
        report_to="none"
    )
    
    # Initialize Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=test_dataset,
        compute_metrics=compute_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=2)]
    )
    
    try:
        # Train the model (resume if checkpoint exists)
        checkpoint = None
        if os.path.exists(os.path.join(output_dir, 'checkpoint-latest')):
            checkpoint = os.path.join(output_dir, 'checkpoint-latest')
            print(f"Resuming training from checkpoint: {checkpoint}")
        
        print("Starting training...")
        train_result = trainer.train(resume_from_checkpoint=checkpoint)
        
        # Save final model
        trainer.save_model(os.path.join(output_dir, 'final_model'))
        tokenizer.save_pretrained(os.path.join(output_dir, 'final_model'))
        
        # Evaluate
        print("\nFinal Evaluation:")
        eval_results = trainer.evaluate()
        print(f"Accuracy: {eval_results['eval_accuracy']:.4f}")
        print(f"F1 Macro: {eval_results['eval_f1_macro']:.4f}")
        
        # Save training metrics
        metrics = {
            'train_metrics': train_result.metrics,
            'eval_metrics': eval_results
        }
        with open(os.path.join(output_dir, 'training_metrics.json'), 'w') as f:
            json.dump(metrics, f, indent=2)
        
        print(f"\nTraining complete! Model saved to: {output_dir}")
        
    except Exception as e:
        print(f"\nTraining interrupted: {str(e)}")
        print(f"Partial results saved to: {output_dir}")
        # Save whatever we have so far
        trainer.save_model(os.path.join(output_dir, 'interrupted_model'))
        tokenizer.save_pretrained(os.path.join(output_dir, 'interrupted_model'))

if __name__ == '__main__':
    print(f"Using device: {'cuda' if torch.cuda.is_available() else 'cpu'}")
    train_email_classifier()